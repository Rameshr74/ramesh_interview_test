package com.worldline.onlineproductsale.service;

import com.worldline.onlineproductsale.dto.OrderItemDTO;
import com.worldline.onlineproductsale.entity.Customer;
import com.worldline.onlineproductsale.entity.CustomerIdentifier;
import com.worldline.onlineproductsale.entity.Organization;
import com.worldline.onlineproductsale.entity.Person;
import com.worldline.onlineproductsale.enums.ProductType;
import com.worldline.onlineproductsale.exception.ApplicationException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

@ExtendWith(MockitoExtension.class)
class ShoppingCartTest {

    @InjectMocks
    ShoppingCart shoppingCart;

    @Test
    void calculateShoppingCartTotal_withResidentialCustomerAndItems_returnsValidTotal() {
        Customer customer = new Person(new CustomerIdentifier(1), "Ramesh", "Rajendra");
        List<OrderItemDTO> items = Arrays.asList(
                new OrderItemDTO(ProductType.HIGH_END_PHONE, "Apple", 5),
                new OrderItemDTO(ProductType.MID_RANGE_PHONE, "Samsung", 3),
                new OrderItemDTO(ProductType.LAPTOP, "HP", 10)
        );

        Double total = shoppingCart.getShoppingCartTotal(customer, items);

        assertEquals(21900.00, total);
    }

    @Test
    void calculateShoppingCartTotal_withResidentialCustomerAndNoItems_returnsZeroTotal() {
        Customer customer = new Person(new CustomerIdentifier(1), "Ramesh", "Rajendra");
        List<OrderItemDTO> items = new ArrayList<>();

        Double total = shoppingCart.getShoppingCartTotal(customer, items);

        assertEquals(0.00, total);
    }

    @Test
    void calculateShoppingCartTotal_withSmallEnterpriseCustomerAndItems_returnsValidTotal() {
        Customer customer = new Organization(new CustomerIdentifier(2), "Birla", "BE123", "123", 800000.00);
        List<OrderItemDTO> items = Arrays.asList(
                new OrderItemDTO(ProductType.HIGH_END_PHONE, "Apple", 5),
                new OrderItemDTO(ProductType.MID_RANGE_PHONE, "Samsung", 3),
                new OrderItemDTO(ProductType.LAPTOP, "HP", 10)
        );

        Double total = shoppingCart.getShoppingCartTotal(customer, items);

        assertEquals(17550.00, total);
    }

    @Test
    void calculateShoppingCartTotal_withSmallEnterpriseCustomerAndNoItems_returnsZeroTotal() {
        Customer customer = new Organization(new CustomerIdentifier(2), "Birla", "BE123", "123", 800000.00);
        List<OrderItemDTO> items = new ArrayList<>();

        Double total = shoppingCart.getShoppingCartTotal(customer, items);

        assertEquals(0.00, total);
    }

    @Test
    void calculateShoppingCartTotal_withCorporateCustomerAndItems_returnsValidTotal() {
        Customer customer = new Organization(new CustomerIdentifier(3), "Tata", "BE456", "456", 12000000.00);
        List<OrderItemDTO> items = Arrays.asList(
                new OrderItemDTO(ProductType.HIGH_END_PHONE, "Apple", 5),
                new OrderItemDTO(ProductType.MID_RANGE_PHONE, "Samsung", 3),
                new OrderItemDTO(ProductType.LAPTOP, "HP", 10)
        );

        Double total = shoppingCart.getShoppingCartTotal(customer, items);

        assertEquals(15650.00, total);
    }

    @Test
    void calculateShoppingCartTotal_withCorporateCustomerAndNoItems_returnsZeroTotal() {
        Customer customer = new Organization(new CustomerIdentifier(3), "Tata", "BE456", "456", 12000000.00);
        List<OrderItemDTO> items = new ArrayList<>();

        Double total = shoppingCart.getShoppingCartTotal(customer, items);

        assertEquals(0.00, total);
    }

    @Test
    void shouldThrowException_whenAnnualRevenueInOrganizationFromClientIsNull() {
        Customer customer = new Organization(new CustomerIdentifier(4), "Test", "BE789", "456", null);
        List<OrderItemDTO> items = new ArrayList<>();

        assertThrows(ApplicationException.class, () -> shoppingCart.getShoppingCartTotal(customer, items));
    }
}
