package com.worldline.onlineproductsale;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineProductSaleApplicationTests {

	@Test
	void contextLoads() {
	}

}
