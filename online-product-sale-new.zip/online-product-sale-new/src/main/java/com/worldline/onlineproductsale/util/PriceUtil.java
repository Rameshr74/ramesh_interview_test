package com.worldline.onlineproductsale.util;

import com.worldline.onlineproductsale.entity.ProductPrice;
import com.worldline.onlineproductsale.enums.CustomerCategory;
import com.worldline.onlineproductsale.enums.ProductType;

import java.util.Arrays;
import java.util.List;

public class PriceUtil {

    private PriceUtil() {}

    private static final List<ProductPrice> productPrices = Arrays.asList(
            new ProductPrice(CustomerCategory.RESIDENTIAL, ProductType.HIGH_END_PHONE, 1500.00),
            new ProductPrice(CustomerCategory.RESIDENTIAL, ProductType.MID_RANGE_PHONE, 800.00),
            new ProductPrice(CustomerCategory.RESIDENTIAL, ProductType.LAPTOP, 1200.00),
            new ProductPrice(CustomerCategory.CORPORATE, ProductType.HIGH_END_PHONE, 1000.00),
            new ProductPrice(CustomerCategory.CORPORATE, ProductType.MID_RANGE_PHONE, 550.00),
            new ProductPrice(CustomerCategory.CORPORATE, ProductType.LAPTOP, 900.00),
            new ProductPrice(CustomerCategory.SMALL_ENTERPRISE, ProductType.HIGH_END_PHONE, 1150.00),
            new ProductPrice(CustomerCategory.SMALL_ENTERPRISE, ProductType.MID_RANGE_PHONE, 600.00),
            new ProductPrice(CustomerCategory.SMALL_ENTERPRISE, ProductType.LAPTOP, 1000.00)
    );

    public static Double getPrice(CustomerCategory category, ProductType type) {
        return productPrices.stream()
                .filter(p -> p.getCategory().equals(category) && p.getType().equals(type))
                .map(ProductPrice::getAmount)
                .findFirst().orElse(0.0);
    }

}
