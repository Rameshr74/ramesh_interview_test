package com.worldline.onlineproductsale.enums;

public enum CustomerCategory {
    RESIDENTIAL,
    SMALL_ENTERPRISE,
    CORPORATE
}
