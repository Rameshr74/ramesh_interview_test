package com.worldline.onlineproductsale.entity;

import com.worldline.onlineproductsale.enums.CustomerCategory;
import com.worldline.onlineproductsale.enums.ProductType;

public class ProductPrice {
    private CustomerCategory category;
    private ProductType type;
    private Double amount;

    public ProductPrice(CustomerCategory category, ProductType type, Double amount) {
        this.category = category;
        this.type = type;
        this.amount = amount;
    }

    public CustomerCategory getCategory() {
        return category;
    }

    public void setCategory(CustomerCategory category) {
        this.category = category;
    }

    public ProductType getType() {
        return type;
    }

    public void setType(ProductType type) {
        this.type = type;
    }

    public Double getAmount() {
        return amount;
    }

    public void setAmount(Double amount) {
        this.amount = amount;
    }
}
