package com.worldline.onlineproductsale.util;

public class CommonConstants {
    public static final Double MINIMUM_CORPORATE_REVENUE = 10000000.00;

    private CommonConstants() {}
}
