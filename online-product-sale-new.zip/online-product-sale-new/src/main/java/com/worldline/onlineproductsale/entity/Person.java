package com.worldline.onlineproductsale.entity;

import com.worldline.onlineproductsale.enums.CustomerCategory;

public class Person implements Customer {
    private CustomerIdentifier id;
    private String firstName;
    private String lastName;

    public Person(CustomerIdentifier id, String firstName, String lastName) {
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
    }

    @Override
    public CustomerCategory getCustomerCategory() {
        return CustomerCategory.RESIDENTIAL;
    }
}
