package com.worldline.onlineproductsale.service;

import com.worldline.onlineproductsale.dto.OrderItemDTO;
import com.worldline.onlineproductsale.entity.Customer;
import com.worldline.onlineproductsale.enums.CustomerCategory;
import com.worldline.onlineproductsale.util.PriceUtil;

import java.util.List;

public class ShoppingCart {

    public Double getShoppingCartTotal(Customer customer, List<OrderItemDTO> items) {
        final CustomerCategory category = customer.getCustomerCategory();
        return items.stream()
                .map(i -> i.getQuantity() * PriceUtil.getPrice(category, i.getProductType()))
                .reduce(Double::sum).orElse(0.0);
    }

}
