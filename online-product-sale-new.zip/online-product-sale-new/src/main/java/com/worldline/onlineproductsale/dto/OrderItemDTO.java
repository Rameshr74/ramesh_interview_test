package com.worldline.onlineproductsale.dto;

import com.worldline.onlineproductsale.enums.ProductType;

public class OrderItemDTO {
    private ProductType productType;
    private String productName;
    private Integer quantity;

    public OrderItemDTO(ProductType productType, String productName, Integer quantity) {
        this.productType = productType;
        this.productName = productName;
        this.quantity = quantity;
    }

    public ProductType getProductType() {
        return productType;
    }

    public void setProductType(ProductType productType) {
        this.productType = productType;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }
}
