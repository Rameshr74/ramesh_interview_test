package com.worldline.onlineproductsale.enums;

public enum ProductType {
    HIGH_END_PHONE,
    MID_RANGE_PHONE,
    LAPTOP
}
