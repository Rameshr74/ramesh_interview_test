package com.worldline.onlineproductsale.entity;

import com.worldline.onlineproductsale.enums.CustomerCategory;

public interface Customer {
    CustomerCategory getCustomerCategory();
}
