package com.worldline.onlineproductsale.entity;

public class CustomerIdentifier {
    private final Integer id;

    public CustomerIdentifier(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }
}
