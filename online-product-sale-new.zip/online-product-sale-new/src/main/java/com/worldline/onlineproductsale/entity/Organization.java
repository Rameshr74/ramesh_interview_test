package com.worldline.onlineproductsale.entity;

import com.worldline.onlineproductsale.enums.CustomerCategory;
import com.worldline.onlineproductsale.exception.ApplicationException;
import com.worldline.onlineproductsale.util.CommonConstants;

public class Organization implements Customer {
    private CustomerIdentifier id;
    private String name;
    private String vat;
    private String registrationNumber;
    private Double annualRevenue;

    public Organization(CustomerIdentifier id, String name, String vat, String registrationNumber, Double annualRevenue) {
        this.id = id;
        this.name = name;
        this.vat = vat;
        this.registrationNumber = registrationNumber;
        this.annualRevenue = annualRevenue;
    }

    @Override
    public CustomerCategory getCustomerCategory() {
        if (annualRevenue == null) {
            throw new ApplicationException("Organization exists without revenue to calculate category.");
        }

        if (annualRevenue > CommonConstants.MINIMUM_CORPORATE_REVENUE) {
            return CustomerCategory.CORPORATE;
        } else {
            return CustomerCategory.SMALL_ENTERPRISE;
        }
    }
}
